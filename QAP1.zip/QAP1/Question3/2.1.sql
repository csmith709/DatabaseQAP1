SELECT film_id, title, release_year, rental_rate
FROM film;
SELECT * FROM film WHERE language_id = 1;
SELECT rating, COUNT(*) FROM film GROUP BY rating;
SELECT customer_id ,first_name ,last_name FROM customer ORDER BY last_name ASC;
SELECT film.title ,inventory.inventory_id ,rental.rental_date FROM film INNER JOIN inventory 
ON film.film_id = inventory.film_id INNER JOIN rental ON inventory.inventory_id = rental.inventory_id;

INSERT INTO customer (store_id, first_name, last_name, email, address_id, activebool, create_date, last_update)
VALUES
    (1, 'Lochlin', 'Blaque', 'loch.Blaque@example.com', 2, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    (1, 'Serifina', 'Blaque', 'serif.Blaque@example.com', 2, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    (1, 'Arissa', 'Blaque', 'ari.Blaque@example.com', 2, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    (1, 'Jakob', 'Blaque', 'jake.Blaque@example.com', 2, TRUE, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);

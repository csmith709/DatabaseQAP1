SELECT film_id, title, release_year, rental_rate
FROM film;
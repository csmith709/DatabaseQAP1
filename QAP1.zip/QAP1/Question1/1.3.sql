SELECT film_id, title, release_year, rental_rate
FROM film;
SELECT * FROM film WHERE language_id = 1;
SELECT rating, COUNT(*) FROM film GROUP BY rating;
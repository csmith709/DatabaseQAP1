SELECT * 
FROM public."Pet" 
WHERE pet_status = true;

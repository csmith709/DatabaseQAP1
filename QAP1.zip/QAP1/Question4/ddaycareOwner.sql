INSERT INTO public."Owner" (owner_fname, owner_lname, email) 
VALUES 
    ('Milo', 'Briggs', 'milo.briggs@email.com'), 
    ('Anya', 'Anderson', 'anya101@email.com'), 
    ('Morticai', 'Vance', 'morty.vance@email.com'), 
    ('Lauren', 'Nomer', 'laurennomer@email.com'), 
    ('Barry', 'Sanderson', 'b.sanderson709@email.com');


		
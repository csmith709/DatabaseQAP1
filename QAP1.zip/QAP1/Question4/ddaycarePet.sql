INSERT INTO public."Pet" (pet_name, pet_species, pet_breed, pet_status) 
VALUES 
    ('Banjo', 'cat', 'dsh', true),
    ('Monty', 'horse', 'arabian', false), 
    ('Noah', 'dog', 'chihuahua', false), 
    ('Angel', 'dog', 'doberman pincer', true), 
    ('Bubbles', 'bird', 'lovebird', false);
INSERT INTO public."Pet" (pet_name, pet_species, pet_breed, pet_status) 
VALUES 
    ('Boogie', 'horse', 'morgan', true), 
    ('Cassius', 'cat', 'mixed', true), 
    ('Shoto', 'iguana', 'crested', true);
UPDATE public."Pet"
SET owner_id = 
    CASE 
        WHEN pet_name = 'Banjo' THEN 1 
        WHEN pet_name = 'Monty' THEN 2  
        WHEN pet_name = 'Noah' THEN 3  
        WHEN pet_name = 'Angel' THEN 4  
        WHEN pet_name = 'Bubbles' THEN 5
		WHEN pet_name = 'Boogie' THEN 2  
        WHEN pet_name = 'Cassius' THEN 3  
        WHEN pet_name = 'Shoto' THEN 5
    END;
INSERT INTO public."Pet" (pet_name, pet_species, pet_breed, pet_status, owner_id) 
VALUES 
    ('Mickey', 'hampster', 'teddy bear', true, 1), 
    ('Beau', 'horse', 'clydestale', true, 2),
    ('Luna', 'dog', 'siberian husky', true, 3),
    ('Mittens', 'cat', 'siamese', false, 4),
    ('Nano', 'cat', 'Maine coon', true, 5);